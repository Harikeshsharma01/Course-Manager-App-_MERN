const express = require('express');
const { addCourse, showCourse, showCourses, editCourse, delCourse } = require('../controller/courseController');

const routes = express.Router()

routes.post('/add',addCourse)
routes.get('/',showCourses)
routes.get('/:id',showCourse)
routes.put('/:id',editCourse)
routes.delete('/:id',delCourse)

module.exports =routes