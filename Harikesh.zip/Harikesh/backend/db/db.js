const mongoose = require('mongoose');

const connectMongo =()=>{
mongoose.connect('mongodb://localhost:27017/h3')
.then((res) => {
    console.log("DB is connected");
}).catch((err) => {
    console.log(err)
});
}

module.exports= {connectMongo}