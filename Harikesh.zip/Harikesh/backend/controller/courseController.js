const courseModel = require('../model/courseModel');

exports.addCourse=async(req,res)=>{
    try {
        const add_c = new courseModel(req.body)
        const add_course = await add_c.save()
        res.status(200).json(add_course)
    } catch (err) {
        res.status(400).json({ message: err.message })
    }
}

exports.showCourse=async(req,res)=>{
    const show_course = await courseModel.findById(req.params.id)
    res.status(200).json(show_course)
}
exports.showCourses=async(req,res)=>{
    const show_course = await courseModel.find()
    res.status(200).json(show_course)
}

exports.delCourse=async(req,res)=>{
    const del_course = await courseModel.findByIdAndDelete(req.params.id)
    res.status(200).json(del_course)
}

exports.editCourse=async(req,res)=>{
    const edit_course = await courseModel.findByIdAndUpdate(req.params.id,req.body,{new:true})
    res.status(200).json(edit_course)
}
