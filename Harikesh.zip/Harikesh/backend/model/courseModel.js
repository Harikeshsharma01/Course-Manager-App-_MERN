const mongoose = require('mongoose');

const courseschema = new mongoose.Schema({
    id:Number,
    courseName:String,
    instructor:String,
    category:String,
    duration:Number,
    level:String,
    thumbnail:String
},{timestamps:true})

const courseModel =  mongoose.model('course',courseschema)

module.exports = courseModel
