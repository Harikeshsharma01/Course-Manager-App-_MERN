const express = require('express');
const {connectMongo} =require ('./db/db');
const courseRoute = require('./routes/courseRoutes');

const app = express()

connectMongo();

app.use(express.json())
app.use(express.urlencoded({extended:true}))

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', 'http://localhost:5173')
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept')
    res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS')

    if (req.method === 'OPTIONS') {
        return res.sendStatus(204)
    }

    next()
})

app.use('/course',courseRoute)

const PORT = process.env.PORT || 4000
const server = app.listen(PORT, () => {
    console.log(`Server is running on ${PORT}`)
})

server.on('error', (err) => {
    if (err && err.code === 'EADDRINUSE') {
        console.error(`Port ${PORT} is already in use. Set a different PORT or stop the conflicting process.`)
        process.exit(1)
    }
    console.error('Server error:', err)
    process.exit(1)
})

