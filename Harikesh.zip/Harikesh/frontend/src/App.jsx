import { BrowserRouter, Routes, Route } from 'react-router-dom'
import AddCourse from './component/AddCourse'
import ShowCourse from './component/ShowCourse'
import EditCourse from './component/EditCourse'
import DeleteCourse from './component/DeleteCourse'
import Home from './component/Home'
import Navbar from './component/Navbar'
import 'bootstrap/dist/css/bootstrap.min.css'

const App = () => {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/add' element={<AddCourse />} />
        <Route path='/course/:id' element={<ShowCourse />} />
        <Route path='/edit/:id' element={<EditCourse />} />
        <Route path='/delete/:id' element={<DeleteCourse />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
