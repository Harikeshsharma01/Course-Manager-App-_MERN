import axios from 'axios'
import { useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

const DeleteCourse = () => {
  const { id } = useParams()
  const navigate = useNavigate()

  useEffect(() => {
    axios.delete(`http://localhost:4000/course/${id}`)
      .then(() => navigate('/'))
      .catch((err) => console.log(err))
  }, [id, navigate])

  return (
    <div>
      <h1>Deleting course...</h1>
    </div>
  )
}

export default DeleteCourse
