import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import axios from 'axios'

const AddCourse = () => {
    const [course, setCourse] = useState({
        courseName: '',
        instructor: '',
        category: '',
        duration: '',
        level: 'Beginner',
        thumbnail: ''
    })
    const [thumbnailPreview, setThumbnailPreview] = useState('')

    const navigate = useNavigate()

    const handleThumbnailChange = (e) => {
        const file = e.target.files?.[0]

        if (!file) {
            return
        }

        const reader = new FileReader()
        reader.onloadend = () => {
            const imageData = reader.result
            setCourse((prev) => ({ ...prev, thumbnail: imageData }))
            setThumbnailPreview(imageData)
        }
        reader.readAsDataURL(file)
    }

const handlesubmit =(e)=>{
    e.preventDefault()
    const payload = {
        ...course,
        duration: Number(course.duration)
    }

    axios.post('http://localhost:4000/course/add', payload)
    .then(() => navigate('/'))
    .catch((err)=>console.log(err)
    )

}

  return (
    <div>
        <div className="container">
            <div
                className="row justify-content-center align-items-center g-2"
            >
                <div className="col">
                    <div className="card">
                        <div className="card-body">
                            <h4 className="card-title">Add_Course</h4>
                            <form onSubmit={handlesubmit}>
                            <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="courseName"
                                    id="courseName"
                                    placeholder="Course Name"
                                    value={course.courseName}
                                    onChange={(e)=>setCourse({...course,courseName:e.target.value})}
                                />
                                          <label htmlFor="courseName">Course Name</label>
                            </div>
                                      <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="instructor"
                                    id="instructor"
                                    placeholder="Instructor Name"
                                    value={course.instructor}
                                    onChange={(e)=>setCourse({...course,instructor:e.target.value})}
                                />
                                          <label htmlFor="instructor">Instructor Name</label>
                            </div>
                                      <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="category"
                                    id="category"
                                    placeholder="Category"
                                    value={course.category}
                                    onChange={(e)=>setCourse({...course,category:e.target.value})}
                                />
                                          <label htmlFor="category">Category</label>
                            </div>
                                      <div className="form-floating mb-3">
                                <input
                                    type="number"
                                    className="form-control"
                                    name="duration"
                                    id="duration"
                                    placeholder="Duration in hours"
                                    min="0"
                                    step="0.5"
                                    value={course.duration}
                                    onChange={(e)=>setCourse({...course,duration:e.target.value})}
                                />
                                          <label htmlFor="duration">Duration (hours)</label>
                            </div>
                                      <div className="form-floating mb-3">
                                <select
                                    className="form-select"
                                    name="level"
                                    id="level"
                                    value={course.level}
                                    onChange={(e)=>setCourse({...course,level:e.target.value})}
                                >
                                    <option value="Beginner">Beginner</option>
                                    <option value="Intermediate">Intermediate</option>
                                    <option value="Advanced">Advanced</option>
                                </select>
                                          <label htmlFor="level">Level</label>
                            </div>
                                      <div className="mb-3">
                                <input
                                    type="file"
                                    className="form-control"
                                    name="thumbnail"
                                    id="thumbnail"
                                    accept="image/*"
                                    onChange={handleThumbnailChange}
                                />
                                <label htmlFor="thumbnail" className="form-label mt-2">Course Thumbnail</label>
                                {thumbnailPreview ? (
                                    <div className="mt-2">
                                        <img src={thumbnailPreview} alt="Thumbnail preview" className="img-fluid rounded" style={{ maxHeight: '180px', objectFit: 'cover' }} />
                                    </div>
                                ) : null}
                            </div>
                            <button
                                type="submit"
                                className="btn btn-primary"
                                
                            >
                                Submit
                            </button>
                            </form>
                            
                            
                        </div>
                    </div>
                    
                </div>
            </div>
            
        </div>
        
    </div>
  )
}

export default AddCourse
