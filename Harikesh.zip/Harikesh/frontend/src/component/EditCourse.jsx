import axios from 'axios'
import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

const EditCourse = () => {
    const [course, setCourse] = useState({
        courseName: '',
        instructor: '',
        category: '',
        duration: '',
        level: 'Beginner',
        thumbnail: ''
    })
    const [thumbnailPreview, setThumbnailPreview] = useState('')

    const { id } = useParams()
    const navigate = useNavigate()

    useEffect(() => {
        axios.get(`http://localhost:4000/course/${id}`)
            .then((res) => {
                setCourse(res.data)
                setThumbnailPreview(res.data.thumbnail)
            })
            .catch((err) => console.log(err))
    }, [id])

    const handleThumbnailChange = (e) => {
        const file = e.target.files?.[0]

        if (!file) {
            return
        }

        const reader = new FileReader()
        reader.onloadend = () => {
            const imageData = reader.result
            setCourse((prev) => ({ ...prev, thumbnail: imageData }))
            setThumbnailPreview(imageData)
        }
        reader.readAsDataURL(file)
    }

    const handleedit = (e) => {
        e.preventDefault()
        const payload = {
            ...course,
            duration: Number(course.duration)
        }

        axios.put(`http://localhost:4000/course/${id}`, payload)
            .then(() => navigate('/'))
            .catch((err) => console.log(err))
    }

  return (
    <div>
        <div
            className="container"
        >
            <div
                className="row justify-content-center align-items-center g-2"
            >
                <div className="col">
                    <div className="card">
                        <div className="card-body">
                            <h4 className="card-title">Edit Course</h4>
                            <form onSubmit={handleedit}>
                            <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="courseName"
                                    id="editCourseName"
                                    placeholder="Course Name"
                                    value={course.courseName || ''}
                                    onChange={(e) => setCourse({ ...course, courseName: e.target.value })}
                                />
                                <label htmlFor="editCourseName">Course Name</label>
                            </div>
                             <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="instructor"
                                    id="editInstructor"
                                    placeholder="Instructor Name"
                                    value={course.instructor || ''}
                                    onChange={(e) => setCourse({ ...course, instructor: e.target.value })}
                                />
                                <label htmlFor="editInstructor">Instructor Name</label>
                            </div>
                             <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="category"
                                    id="editCategory"
                                    placeholder="Category"
                                    value={course.category || ''}
                                    onChange={(e) => setCourse({ ...course, category: e.target.value })}
                                />
                                <label htmlFor="editCategory">Category</label>
                            </div>
                             <div className="form-floating mb-3">
                                <input
                                    type="number"
                                    className="form-control"
                                    name="duration"
                                    id="editDuration"
                                    placeholder="Duration in hours"
                                    min="0"
                                    step="0.5"
                                    value={course.duration || ''}
                                    onChange={(e) => setCourse({ ...course, duration: e.target.value })}
                                />
                                <label htmlFor="editDuration">Duration (hours)</label>
                            </div>
                             <div className="form-floating mb-3">
                                <select
                                    className="form-select"
                                    name="level"
                                    id="editLevel"
                                    value={course.level || 'Beginner'}
                                    onChange={(e) => setCourse({ ...course, level: e.target.value })}
                                >
                                    <option value="Beginner">Beginner</option>
                                    <option value="Intermediate">Intermediate</option>
                                    <option value="Advanced">Advanced</option>
                                </select>
                                <label htmlFor="editLevel">Level</label>
                            </div>
                             <div className="mb-3">
                                <input
                                    type="file"
                                    className="form-control"
                                    name="thumbnail"
                                    id="editThumbnail"
                                    accept="image/*"
                                    onChange={handleThumbnailChange}
                                />
                                <label htmlFor="editThumbnail" className="form-label mt-2">Course Thumbnail</label>
                                {thumbnailPreview ? (
                                    <div className="mt-2">
                                        <img src={thumbnailPreview} alt="Thumbnail preview" className="img-fluid rounded" style={{ maxHeight: '180px', objectFit: 'cover' }} />
                                    </div>
                                ) : null}
                            </div>
                            <button
                                type="submit"
                                className="btn btn-primary"
                            >
                                Submit
                            </button>
                            </form>
                            
                        </div>
                    </div>
                    
                </div>
            </div>
            
        </div>
        
    </div>

  )

}


export default EditCourse
