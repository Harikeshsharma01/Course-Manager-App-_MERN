import { useEffect, useMemo, useState } from 'react'
import { NavLink } from 'react-router-dom'
import axios from 'axios'

const Home = () => {
    const [course,setCourse] = useState([])
    const [filters, setFilters] = useState({
        courseName: '',
        instructor: '',
        category: '',
        level: ''
    })

useEffect(()=>{
  axios.get('http://localhost:4000/course')
    .then((res)=>setCourse(res.data))
        .catch((err)=>console.log(err))
},[])

    const filteredCourses = useMemo(() => {
        return course.filter((item) => {
            const matchesCourseName = item.courseName?.toLowerCase().includes(filters.courseName.toLowerCase())
            const matchesInstructor = item.instructor?.toLowerCase().includes(filters.instructor.toLowerCase())
            const matchesCategory = item.category?.toLowerCase().includes(filters.category.toLowerCase())
            const matchesLevel = item.level?.toLowerCase().includes(filters.level.toLowerCase())

            return matchesCourseName && matchesInstructor && matchesCategory && matchesLevel
        })
    }, [course, filters])

    const handleDelete = (courseId) => {
        axios.delete(`http://localhost:4000/course/${courseId}`)
            .then(() => setCourse((prev) => prev.filter((item) => item._id !== courseId)))
            .catch((err) => console.log(err))
    }

  return (
    <div>
      <div className="container py-4">
        <h1 className="mb-4">Courses</h1>
        <div className="card mb-4">
          <div className="card-body">
            <h5 className="card-title mb-3">Search Courses</h5>
            <div className="row g-3">
              <div className="col-md-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Course Name"
                  value={filters.courseName}
                  onChange={(e) => setFilters({ ...filters, courseName: e.target.value })}
                />
              </div>
              <div className="col-md-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Instructor"
                  value={filters.instructor}
                  onChange={(e) => setFilters({ ...filters, instructor: e.target.value })}
                />
              </div>
              <div className="col-md-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Category"
                  value={filters.category}
                  onChange={(e) => setFilters({ ...filters, category: e.target.value })}
                />
              </div>
              <div className="col-md-3">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Level"
                  value={filters.level}
                  onChange={(e) => setFilters({ ...filters, level: e.target.value })}
                />
              </div>
            </div>
          </div>
        </div>
        {filteredCourses.length === 0 ? (
          <p className="text-muted">No courses found. Use Add Course to create one.</p>
        ) : (
          <div className="row justify-content-center align-items-center g-2">
            <div className="col">
              {filteredCourses.map((courses) => (
                <div className="card mb-3" key={courses._id}>
                  <img className="card-img-top" src={courses.thumbnail} alt="Course thumbnail" height={300} width={200} style={{ objectFit: 'cover' }} />
                  <div className="card-body">
                    <h4 className="card-title">{courses.courseName}</h4>
                    <p className="card-text mb-1"><strong>Instructor:</strong> {courses.instructor}</p>
                    <p className="card-text mb-1"><strong>Category:</strong> {courses.category}</p>
                    <p className="card-text mb-1"><strong>Duration:</strong> {courses.duration}</p>
                    <p className="card-text mb-3"><strong>Level:</strong> {courses.level}</p>
                    <div className="d-flex gap-2 flex-wrap">
                      <NavLink to={`/course/${courses._id}`} className="btn btn-primary btn-sm">Show More</NavLink>
                      <NavLink to={`/edit/${courses._id}`} className="btn btn-warning btn-sm">Edit</NavLink>
                      <button type="button" className="btn btn-danger btn-sm" onClick={() => handleDelete(courses._id)}>Delete</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

    </div>
  )
}

export default Home
