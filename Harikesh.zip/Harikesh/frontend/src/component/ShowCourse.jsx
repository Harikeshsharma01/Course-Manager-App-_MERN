import axios from 'axios'
import { useEffect, useState } from 'react'
import { NavLink, useNavigate, useParams } from 'react-router-dom'

const ShowCourse = () => {
  const [course , setCourse] = useState({})
  const { id } = useParams()
  const navigate = useNavigate()

  useEffect(()=>{
    axios.get(`http://localhost:4000/course/${id}`)
    .then((res)=>setCourse(res.data))
        .catch((err)=>{console.log(err)
        })
  }, [id])

    const handledelete =()=>{
    axios.delete(`http://localhost:4000/course/${id}`).then(() => navigate('/'))
        .catch((err)=>console.log(err)
        )
    }
  return (
    <div>
      <div
        className="container"
      >
        <div
            className="row justify-content-center align-items-center g-2"
        >
            <div className="col">
                <div className="card">
                    <img className="card-img-top" src={course.thumbnail} alt="Title" height={300} width={300} />
                    <div className="card-body">
                      <h4 className="card-title">{course.courseName}</h4>
                      <p className="card-text mb-1"><strong>Instructor:</strong> {course.instructor}</p>
                      <p className="card-text mb-1"><strong>Category:</strong> {course.category}</p>
                      <p className="card-text mb-1"><strong>Duration:</strong> {course.duration}</p>
                      <p className="card-text mb-3"><strong>Level:</strong> {course.level}</p>
                      <NavLink to="/" className="btn btn-primary">Back</NavLink><br/>
                      <NavLink to={`/edit/${id}`} className="btn btn-warning me-2">Edit</NavLink>
                     <button type="button" className="btn btn-danger btn-sm" onClick={() => handledelete(id)}>Delete</button>
                    </div>
                </div>
                
            </div>
        </div>
        
      </div>
      
    </div>
  )
}

export default ShowCourse
